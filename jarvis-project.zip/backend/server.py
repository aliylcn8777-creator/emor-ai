from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import re
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone

from emergentintegrations.llm.chat import LlmChat, UserMessage


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY', '')

app = FastAPI(title="Jarvis AI Assistant")
api_router = APIRouter(prefix="/api")


# -------- Models --------
class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None


class ChatResponse(BaseModel):
    session_id: str
    reply: str
    intent: Optional[str] = None
    action: Optional[dict] = None
    timestamp: str


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    session_id: str
    role: str  # "user" | "assistant"
    content: str
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class CactusState(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = "singleton"
    tank_level: float = 100.0  # percentage 0-100
    moisture: float = 30.0     # percentage 0-100
    tank_capacity_ml: int = 500
    last_watered: Optional[str] = None
    total_waterings: int = 0


# -------- Intent detection --------
WATER_PATTERNS = [
    r"kakt[üu]se?\s+s[uıiİ]",
    r"s[uıi]\s+ver",
    r"sula",
    r"water\s+the\s+cactus",
    r"water\s+cactus",
    r"give\s+water",
]

REFILL_PATTERNS = [
    r"depo(yu)?\s+doldur",
    r"tank(ı)?\s+doldur",
    r"su\s+doldur",
    r"refill",
    r"fill\s+(the\s+)?tank",
]

STATUS_PATTERNS = [
    r"durum",
    r"kakt[üu]s\s+nas[ıi]l",
    r"depo(da)?\s+ne\s+kadar",
    r"status",
]


def detect_intent(text: str) -> Optional[str]:
    t = text.lower()
    for p in WATER_PATTERNS:
        if re.search(p, t):
            return "water_cactus"
    for p in REFILL_PATTERNS:
        if re.search(p, t):
            return "refill_tank"
    for p in STATUS_PATTERNS:
        if re.search(p, t):
            return "status"
    return None


# -------- Cactus helpers --------
async def get_cactus_state() -> dict:
    state = await db.cactus.find_one({"id": "singleton"}, {"_id": 0})
    if not state:
        default = CactusState().model_dump()
        await db.cactus.insert_one(default.copy())
        state = default
    return state


async def water_cactus(amount_ml: int = 50) -> dict:
    state = await get_cactus_state()
    tank = state["tank_level"]
    pct_used = (amount_ml / state["tank_capacity_ml"]) * 100
    if tank < pct_used:
        return {"ok": False, "reason": "tank_empty", "state": state}
    new_tank = max(0.0, tank - pct_used)
    new_moisture = min(100.0, state["moisture"] + 25.0)
    now_iso = datetime.now(timezone.utc).isoformat()
    await db.cactus.update_one(
        {"id": "singleton"},
        {"$set": {
            "tank_level": new_tank,
            "moisture": new_moisture,
            "last_watered": now_iso,
        }, "$inc": {"total_waterings": 1}},
        upsert=True,
    )
    new_state = await get_cactus_state()
    return {"ok": True, "amount_ml": amount_ml, "state": new_state}


async def refill_tank() -> dict:
    now_iso = datetime.now(timezone.utc).isoformat()
    await db.cactus.update_one(
        {"id": "singleton"},
        {"$set": {"tank_level": 100.0, "last_refilled": now_iso}},
        upsert=True,
    )
    state = await get_cactus_state()
    return {"ok": True, "state": state}


# -------- Routes --------
@api_router.get("/")
async def root():
    return {"message": "Jarvis Online", "status": "ok"}


@api_router.get("/cactus/state")
async def api_cactus_state():
    state = await get_cactus_state()
    return state


@api_router.post("/cactus/water")
async def api_cactus_water(amount_ml: int = 50):
    result = await water_cactus(amount_ml=amount_ml)
    return result


@api_router.post("/cactus/refill")
async def api_cactus_refill():
    return await refill_tank()


SYSTEM_PROMPT = (
    "Sen JARVIS adında, Türkçe konuşan, zeki ve nazik bir yapay zeka asistanısın. "
    "Bir kaktüs sulama sistemini kontrol ediyorsun. "
    "Kullanıcı kaktüse su vermeni isterse kısa ve onaylayıcı bir cevap ver (örn: 'Tamamdır efendim, kaktüse 50ml su veriyorum.'). "
    "Su deposunu doldurmak isterse onayla (örn: 'Depo yenileniyor efendim, 500ml kapasitesine ulaşıldı.'). "
    "Durum sorarsa mevcut tank ve nem durumunu kısaca özetle. "
    "Diğer konularda yardımcı ol ama cevaplarını 1-3 cümlede tut, kısa ve etkili konuş. "
    "Asla uzun listeler veya markdown kullanma - sesli okunacak cümleler üret."
)


def _build_context_note(state: dict) -> str:
    return (
        f"[SISTEM DURUMU] Tank: %{state['tank_level']:.0f} dolu, "
        f"toprak nemi: %{state['moisture']:.0f}, "
        f"toplam sulama: {state['total_waterings']}."
    )


async def _execute_intent_action(intent: Optional[str]) -> Optional[dict]:
    if intent == "water_cactus":
        return await water_cactus(amount_ml=50)
    if intent == "refill_tank":
        return await refill_tank()
    return None


def _append_action_hint(prompt_text: str, intent: Optional[str], action_result: Optional[dict]) -> str:
    if not action_result:
        return prompt_text
    if action_result.get("ok"):
        if intent == "water_cactus":
            level = action_result["state"]["tank_level"]
            return prompt_text + f"\n\n[AKSIYON TAMAMLANDI] Kaktüse 50ml su verildi. Yeni tank seviyesi: %{level:.0f}"
        if intent == "refill_tank":
            return prompt_text + "\n\n[AKSIYON TAMAMLANDI] Su deposu tam dolduruldu (%100)."
        return prompt_text
    return prompt_text + "\n\n[UYARI] Tank boş, önce depo doldurulmalı."


async def _generate_reply(session_id: str, prompt_text: str) -> str:
    try:
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=session_id,
            system_message=SYSTEM_PROMPT,
        ).with_model("openai", "gpt-4o")
        reply = await chat.send_message(UserMessage(text=prompt_text))
        return str(reply).strip()
    except Exception:
        logging.exception("LLM error")
        return "Bağlantımda bir sorun var efendim, lütfen tekrar deneyin."


@api_router.post("/chat", response_model=ChatResponse)
async def api_chat(req: ChatRequest):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(status_code=500, detail="LLM key not configured")

    user_text = req.message.strip()
    if not user_text:
        raise HTTPException(status_code=400, detail="Empty message")

    session_id = req.session_id or str(uuid.uuid4())
    intent = detect_intent(user_text)

    state = await get_cactus_state()
    action_result = await _execute_intent_action(intent)

    prompt_text = f"{_build_context_note(state)}\n\nKullanıcı: {user_text}"
    prompt_text = _append_action_hint(prompt_text, intent, action_result)

    await db.chat_history.insert_one(
        ChatMessage(session_id=session_id, role="user", content=user_text).model_dump()
    )

    reply = await _generate_reply(session_id, prompt_text)

    await db.chat_history.insert_one(
        ChatMessage(session_id=session_id, role="assistant", content=reply).model_dump()
    )

    return ChatResponse(
        session_id=session_id,
        reply=reply,
        intent=intent,
        action=action_result,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@api_router.get("/chat/history/{session_id}")
async def get_history(session_id: str):
    msgs = await db.chat_history.find({"session_id": session_id}, {"_id": 0}).sort("timestamp", 1).to_list(1000)
    return msgs


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
