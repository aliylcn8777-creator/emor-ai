"""Backend API tests for Jarvis cactus assistant."""
import os
import time
import uuid
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://6626d9b5-62e1-4445-9910-bda2c7b81650.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def _assert_no_mongo_id(obj):
    """Recursively ensure no _id field leaked."""
    if isinstance(obj, dict):
        assert "_id" not in obj, f"_id leaked in response: {obj}"
        for v in obj.values():
            _assert_no_mongo_id(v)
    elif isinstance(obj, list):
        for v in obj:
            _assert_no_mongo_id(v)


# ---- Root ----
class TestRoot:
    def test_root_returns_status_ok(self, client):
        r = client.get(f"{API}/")
        assert r.status_code == 200
        data = r.json()
        assert data.get("message") == "Jarvis Online"
        assert data.get("status") == "ok"


# ---- Cactus State ----
class TestCactusState:
    def test_get_state_has_required_fields(self, client):
        r = client.get(f"{API}/cactus/state")
        assert r.status_code == 200
        data = r.json()
        _assert_no_mongo_id(data)
        for k in ("tank_level", "moisture", "tank_capacity_ml", "total_waterings"):
            assert k in data, f"missing {k}"
        assert data["tank_capacity_ml"] == 500
        assert 0 <= data["tank_level"] <= 100
        assert 0 <= data["moisture"] <= 100


# ---- Direct cactus water/refill ----
class TestCactusWaterRefill:
    def test_refill_then_water_decreases_tank(self, client):
        # Refill to 100 first
        r = client.post(f"{API}/cactus/refill")
        assert r.status_code == 200
        data = r.json()
        _assert_no_mongo_id(data)
        assert data["ok"] == True
        assert data["state"]["tank_level"] == 100.0

        before = data["state"]
        w = client.post(f"{API}/cactus/water")
        assert w.status_code == 200
        wd = w.json()
        _assert_no_mongo_id(wd)
        assert wd["ok"] == True
        # 50ml of 500ml = 10%
        assert abs(wd["state"]["tank_level"] - (before["tank_level"] - 10)) < 0.001
        assert wd["state"]["total_waterings"] == before["total_waterings"] + 1

    def test_water_until_empty_returns_tank_empty(self, client):
        # Refill fresh
        client.post(f"{API}/cactus/refill")
        last = None
        for _ in range(12):  # 10 waterings drain it; 11th should fail
            r = client.post(f"{API}/cactus/water")
            assert r.status_code == 200
            last = r.json()
            if not last.get("ok"):
                break
        assert last is not None
        assert last["ok"] is False
        assert last.get("reason") == "tank_empty"

    def test_refill_sets_tank_100(self, client):
        r = client.post(f"{API}/cactus/refill")
        assert r.status_code == 200
        d = r.json()
        assert d["ok"] is True
        assert d["state"]["tank_level"] == 100.0


# ---- Chat ----
class TestChat:
    def test_empty_message_returns_400(self, client):
        r = client.post(f"{API}/chat", json={"message": ""})
        assert r.status_code == 400

    def test_empty_whitespace_returns_400(self, client):
        r = client.post(f"{API}/chat", json={"message": "   "})
        assert r.status_code == 400

    def test_water_cactus_intent(self, client):
        # Ensure tank has room
        client.post(f"{API}/cactus/refill")
        before = client.get(f"{API}/cactus/state").json()
        session_id = str(uuid.uuid4())
        r = client.post(f"{API}/chat", json={"message": "kaktüse su ver", "session_id": session_id})
        assert r.status_code == 200
        d = r.json()
        _assert_no_mongo_id(d)
        assert d["intent"] == "water_cactus"
        assert d["action"]["ok"] == True
        assert d["session_id"] == session_id
        assert isinstance(d.get("reply"), str) and len(d["reply"]) > 0
        after_state = d["action"]["state"]
        assert abs(after_state["tank_level"] - (before["tank_level"] - 10)) < 0.001
        expected_moisture = min(100.0, before["moisture"] + 25.0)
        assert abs(after_state["moisture"] - expected_moisture) < 0.001

    def test_refill_intent(self, client):
        # Drain a bit first
        client.post(f"{API}/cactus/water")
        r = client.post(f"{API}/chat", json={"message": "depoyu doldur"})
        assert r.status_code == 200
        d = r.json()
        _assert_no_mongo_id(d)
        assert d["intent"] == "refill_tank"
        assert d["action"]["ok"] == True
        assert d["action"]["state"]["tank_level"] == 100.0

    def test_status_intent(self, client):
        r = client.post(f"{API}/chat", json={"message": "durum nedir?"})
        assert r.status_code == 200
        d = r.json()
        _assert_no_mongo_id(d)
        assert d["intent"] == "status"
        assert isinstance(d["reply"], str) and len(d["reply"]) > 0

    def test_greeting_no_intent(self, client):
        r = client.post(f"{API}/chat", json={"message": "merhaba jarvis"})
        assert r.status_code == 200
        d = r.json()
        _assert_no_mongo_id(d)
        assert d["intent"] is None
        assert isinstance(d["reply"], str) and len(d["reply"]) > 0

    def test_session_persistence_and_history(self, client):
        session_id = str(uuid.uuid4())
        r1 = client.post(f"{API}/chat", json={"message": "merhaba", "session_id": session_id})
        assert r1.status_code == 200
        r2 = client.post(f"{API}/chat", json={"message": "nasılsın", "session_id": session_id})
        assert r2.status_code == 200
        time.sleep(0.5)
        h = client.get(f"{API}/chat/history/{session_id}")
        assert h.status_code == 200
        msgs = h.json()
        _assert_no_mongo_id(msgs)
        assert isinstance(msgs, list)
        assert len(msgs) == 4
        roles = [m["role"] for m in msgs]
        assert roles == ["user", "assistant", "user", "assistant"]
        contents = [m["content"] for m in msgs]
        assert "merhaba" in contents[0]
        assert "nasılsın" in contents[2]


# ---- History empty session ----
class TestHistory:
    def test_unknown_session_returns_empty(self, client):
        r = client.get(f"{API}/chat/history/{uuid.uuid4()}")
        assert r.status_code == 200
        assert r.json() == []
