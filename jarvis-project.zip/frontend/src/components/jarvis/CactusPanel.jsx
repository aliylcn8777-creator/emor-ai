import { Droplets, RefreshCcw } from "lucide-react";

export default function CactusPanel({ cactus, showDrop, onWater, onRefill }) {
  const tank = Math.max(0, Math.min(100, cactus.tank_level ?? 0));
  const moisture = Math.max(0, Math.min(100, cactus.moisture ?? 0));
  const dry = moisture < 35;

  return (
    <div className="hud-panel p-5" data-testid="cactus-panel">
      <div className="flex items-center justify-between mb-3">
        <span className="hud-label">Greenhouse Unit 01</span>
        <Droplets size={14} className="text-cyan-300" />
      </div>

      <div className="flex items-end justify-between gap-2 px-1">
        {/* Water Tank */}
        <div className="flex flex-col items-center gap-2">
          <div className="water-tank" data-testid="water-tank">
            <div
              className="water-fill"
              style={{ height: `${tank}%` }}
              data-testid="water-tank-fill"
            />
            <div className="tank-ticks">
              <span>100</span>
              <span>75</span>
              <span>50</span>
              <span>25</span>
              <span>0</span>
            </div>
          </div>
          <div className="font-mono-hud text-[11px] text-cyan-200" data-testid="tank-level-text">
            TANK {tank.toFixed(0)}%
          </div>
        </div>

        {/* Cactus */}
        <div className="cactus-stage" data-testid="cactus-stage">
          {showDrop && <div className="water-drop" />}
          <div className="cactus-pot" />
          <div className={`cactus-body ${showDrop ? "hydrated" : ""} ${dry ? "dry" : ""}`}>
            {/* spines */}
            {[18, 38, 58, 78, 98].map((t, i) => (
              <span key={`s-${i}`} className="cactus-spine" style={{ top: `${t}px`, left: "6px" }} />
            ))}
            {[28, 48, 68, 88].map((t, i) => (
              <span key={`s2-${i}`} className="cactus-spine" style={{ top: `${t}px`, right: "6px" }} />
            ))}
          </div>
          <div className="cactus-arm left" />
          <div className="cactus-arm right" />
        </div>
      </div>

      <div className="divider-hud my-4" />

      <div className="grid grid-cols-2 gap-2 text-[11px] font-mono-hud">
        <Metric label="Toprak Nemi" value={`${moisture.toFixed(0)}%`} warn={dry} />
        <Metric label="Depo" value={`${tank.toFixed(0)}%`} warn={tank < 20} />
      </div>

      <div className="flex gap-2 mt-4">
        <button className="hud-btn flex-1 flex items-center justify-center gap-2" onClick={onWater} data-testid="water-button">
          <Droplets size={14} /> Sula
        </button>
        <button className="hud-btn flex-1 flex items-center justify-center gap-2" onClick={onRefill} data-testid="refill-button">
          <RefreshCcw size={14} /> Doldur
        </button>
      </div>
    </div>
  );
}

function Metric({ label, value, warn }) {
  return (
    <div className={`border px-3 py-2 ${warn ? "border-[#ff4757]/60 text-[#ff9ba3]" : "border-cyan-400/30 text-cyan-100"}`}
      style={{ clipPath: "polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px)" }}
    >
      <div className="opacity-60 text-[9px] tracking-widest uppercase">{label}</div>
      <div className="text-base leading-tight">{value}</div>
    </div>
  );
}
