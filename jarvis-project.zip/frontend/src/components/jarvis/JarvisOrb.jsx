export default function JarvisOrb({ status }) {
  const waveformBars = ["wf1", "wf2", "wf3", "wf4", "wf5", "wf6", "wf7"];
  return (
    <div className="jarvis-orb" data-testid="jarvis-orb" data-status={status}>
      <div className="orb-ring orb-ring-1" />
      <div className="orb-ring orb-ring-2" />
      <div className="orb-ring orb-ring-3" />
      <div className={`orb-core ${status !== "idle" ? status : ""}`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="waveform">
            {waveformBars.map((id) => (
              <span key={id} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
