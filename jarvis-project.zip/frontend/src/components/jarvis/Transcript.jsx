import { useEffect, useRef } from "react";

export default function Transcript({ messages }) {
  const scrollRef = useRef(null);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages]);

  return (
    <div className="hud-panel p-4 w-full" data-testid="transcript-panel">
      <div className="flex items-center justify-between mb-2">
        <span className="hud-label">Conversation Log</span>
        <span className="hud-label opacity-60">{messages.length} entries</span>
      </div>
      <div className="transcript" ref={scrollRef} data-testid="transcript-list">
        {messages.length === 0 && (
          <div className="text-cyan-200/50 text-sm px-2 py-4 text-center">
            <span className="blink">_</span> Bekliyor...
          </div>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`msg-row ${m.role}`} data-testid={`msg-${m.role}-${m.id}`}>
            <span className="role-tag">
              {m.role === "user" ? "// KULLANICI" : "// JARVIS"}
            </span>
            {m.content}
          </div>
        ))}
      </div>
    </div>
  );
}
