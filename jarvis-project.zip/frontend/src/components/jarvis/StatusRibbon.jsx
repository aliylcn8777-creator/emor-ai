import { Power, Cpu, Waves } from "lucide-react";

const STATUS_MAP = {
  idle: { label: "STANDBY", color: "text-cyan-300", dot: "bg-cyan-400" },
  listening: { label: "DİNLİYOR", color: "text-[#ffb347]", dot: "bg-amber-400" },
  thinking: { label: "DÜŞÜNÜYOR", color: "text-purple-300", dot: "bg-purple-400" },
  speaking: { label: "KONUŞUYOR", color: "text-emerald-300", dot: "bg-emerald-400" },
};

function getStatusMeta(status) {
  return STATUS_MAP[status] || STATUS_MAP.idle;
}

export default function StatusRibbon({ status, timeStr, sessionId }) {
  const s = getStatusMeta(status);
  return (
    <header className="absolute top-0 inset-x-0 z-20 border-b border-cyan-400/20 bg-[rgba(3,8,18,0.7)] backdrop-blur-md" data-testid="status-ribbon">
      <div className="mx-auto max-w-[1400px] px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full border border-cyan-400 flex items-center justify-center shadow-[0_0_12px_rgba(0,229,255,0.6)]">
            <Power size={16} className="text-cyan-300" />
          </div>
          <div>
            <div className="font-hud text-xl tracking-[0.3em] text-cyan-100">J.A.R.V.I.S</div>
            <div className="hud-label">Just A Rather Very Intelligent System</div>
          </div>
        </div>

        <div className="flex items-center gap-6 text-[11px] font-mono-hud">
          <div className="flex items-center gap-2" data-testid="status-indicator">
            <span className={`inline-block w-2 h-2 rounded-full ${s.dot} shadow-[0_0_8px_currentColor]`} />
            <span className={s.color}>{s.label}</span>
          </div>
          <div className="hidden md:flex items-center gap-2 text-cyan-200/70">
            <Cpu size={12} /> GPT-4o
          </div>
          <div className="hidden md:flex items-center gap-2 text-cyan-200/70">
            <Waves size={12} /> tr-TR
          </div>
          <div className="text-cyan-200/80">{timeStr}</div>
          <div className="hidden xl:block text-cyan-200/40 truncate max-w-[140px]">
            SID {sessionId?.slice(0, 8)}
          </div>
        </div>
      </div>
    </header>
  );
}
