import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import axios from "axios";
import { Mic, MicOff, Send, Activity } from "lucide-react";
import JarvisOrb from "@/components/jarvis/JarvisOrb";
import CactusPanel from "@/components/jarvis/CactusPanel";
import Transcript from "@/components/jarvis/Transcript";
import StatusRibbon from "@/components/jarvis/StatusRibbon";
import useCactus from "@/hooks/useCactus";
import useSpeech from "@/hooks/useSpeech";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

function makeId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function getMicHint(voiceSupported, status) {
  if (!voiceSupported) return "Sesli giriş bu tarayıcıda desteklenmiyor • metin kullanın";
  if (status === "listening") return "Dinliyorum...";
  return "Konuşmak için tıkla";
}

export default function Jarvis() {
  const [status, setStatus] = useState("idle");
  const [messages, setMessages] = useState([
    {
      id: makeId(),
      role: "assistant",
      content: "Sistem çevrimiçi. Ben JARVIS. Komutlarınızı bekliyorum efendim.",
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [sessionId, setSessionId] = useState(null);
  const [showDrop, setShowDrop] = useState(false);

  const { cactus, setCactus, water: manualWater, refill: manualRefill } = useCactus();

  useEffect(() => {
    setSessionId(makeId());
  }, []);

  const appendMessage = useCallback((role, content) => {
    setMessages((m) => [...m, { id: makeId(), role, content }]);
  }, []);

  const sendMessageRef = useRef(null);

  const handleFinalTranscript = useCallback((text) => {
    sendMessageRef.current?.(text);
  }, []);

  const handleInterim = useCallback((text) => setInputText(text), []);

  const { supported: voiceSupported, speak, startListening } = useSpeech({
    onFinalTranscript: handleFinalTranscript,
    onInterimTranscript: handleInterim,
    onStatusChange: setStatus,
  });

  const sendMessage = useCallback(
    async (text) => {
      const trimmed = (text || "").trim();
      if (!trimmed || !sessionId) return;
      appendMessage("user", trimmed);
      setInputText("");
      setStatus("thinking");
      try {
        const { data } = await axios.post(`${API}/chat`, {
          message: trimmed,
          session_id: sessionId,
        });
        appendMessage("assistant", data.reply);
        if (data.action && data.action.state) setCactus(data.action.state);
        if (data.intent === "water_cactus" && data.action && data.action.ok) {
          setShowDrop(true);
          setTimeout(() => setShowDrop(false), 1300);
        }
        speak(data.reply);
      } catch (err) {
        console.error("Chat send error", err);
        const errMsg = "Bağlantı hatası efendim, lütfen tekrar deneyin.";
        appendMessage("assistant", errMsg);
        speak(errMsg);
        setStatus("idle");
      }
    },
    [sessionId, appendMessage, setCactus, speak]
  );

  useEffect(() => {
    sendMessageRef.current = sendMessage;
  }, [sendMessage]);

  const handleWaterClick = useCallback(async () => {
    const result = await manualWater();
    if (result.ok) {
      setShowDrop(true);
      setTimeout(() => setShowDrop(false), 1300);
    }
  }, [manualWater]);

  const handleMicClick = useCallback(() => {
    startListening(status === "listening");
  }, [startListening, status]);

  const handleFormSubmit = useCallback(
    (e) => {
      e.preventDefault();
      sendMessage(inputText);
    },
    [sendMessage, inputText]
  );

  const timeStr = useMemo(() => new Date().toLocaleTimeString("tr-TR"), [messages]);

  return (
    <div className="relative min-h-screen jarvis-grid-bg overflow-hidden" data-testid="jarvis-root">
      <div className="scan-lines absolute inset-0" />

      <StatusRibbon status={status} timeStr={timeStr} sessionId={sessionId} />

      <main className="relative z-10 mx-auto max-w-[1400px] px-6 pt-28 pb-10 grid grid-cols-12 gap-6">
        <section className="col-span-12 lg:col-span-3 space-y-4">
          <VitalsPanel />
          <QuickCommandsPanel />
        </section>

        <section className="col-span-12 lg:col-span-6 flex flex-col items-center gap-6">
          <JarvisOrb status={status} />

          <div className="flex flex-col items-center gap-3 w-full">
            <button
              onClick={handleMicClick}
              disabled={!voiceSupported}
              className={`mic-btn ${status === "listening" ? "listening" : ""}`}
              data-testid="mic-button"
              aria-label="Mikrofon"
            >
              {status === "listening" ? <MicOff size={36} /> : <Mic size={36} />}
            </button>
            <div className="hud-label">{getMicHint(voiceSupported, status)}</div>

            <form onSubmit={handleFormSubmit} className="w-full flex gap-2 mt-2" data-testid="text-input-form">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Komut girin... (örn: kaktüse su ver)"
                className="flex-1 bg-black/40 border border-cyan-400/40 text-cyan-100 px-4 py-3 font-mono-hud text-sm focus:outline-none focus:border-cyan-300 focus:shadow-[0_0_20px_rgba(0,229,255,0.3)]"
                style={{ clipPath: "polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px)" }}
                data-testid="text-input"
              />
              <button type="submit" className="hud-btn flex items-center gap-2" data-testid="send-button" disabled={!inputText.trim()}>
                <Send size={14} /> Gönder
              </button>
            </form>
          </div>

          <Transcript messages={messages} />
        </section>

        <section className="col-span-12 lg:col-span-3 space-y-4">
          <CactusPanel cactus={cactus} showDrop={showDrop} onWater={handleWaterClick} onRefill={manualRefill} />
          <BioReadoutPanel totalWaterings={cactus.total_waterings || 0} />
        </section>
      </main>

      <footer className="relative z-10 text-center pb-4 hud-label" data-testid="footer-tag">
        JARVIS v1.0 • OpenAI GPT-4o • Web Speech API • Built for <span className="text-cyan-300">GitHub</span>
      </footer>
    </div>
  );
}

function VitalsPanel() {
  return (
    <div className="hud-panel p-5" data-testid="system-vitals">
      <div className="flex items-center justify-between mb-3">
        <span className="hud-label">System Vitals</span>
        <Activity size={14} className="text-cyan-300" />
      </div>
      <Vital label="CPU Load" value={42} color="cyan" />
      <Vital label="Neural Net" value={88} color="cyan" />
      <Vital label="Memory" value={61} color="cyan" />
      <Vital label="Signal" value={94} color="gold" />
    </div>
  );
}

function QuickCommandsPanel() {
  const commands = ["Kaktüse su ver", "Depoyu doldur", "Durum nedir?", "Merhaba Jarvis"];
  return (
    <div className="hud-panel p-5" data-testid="quick-commands">
      <span className="hud-label">Quick Commands</span>
      <div className="mt-3 grid gap-2 text-[13px] text-cyan-100/80 font-mono-hud">
        {commands.map((c) => (
          <CmdHint key={c} text={c} />
        ))}
      </div>
    </div>
  );
}

function BioReadoutPanel({ totalWaterings }) {
  return (
    <div className="hud-panel p-5" data-testid="bio-readout">
      <span className="hud-label">Bio-Readout</span>
      <div className="mt-3 space-y-2 font-mono-hud text-[12px] text-cyan-100/80">
        <Row k="Tür" v="Cactaceae" />
        <Row k="Optimum Nem" v="45–65%" />
        <Row k="Sulama Aralığı" v="7–14 gün" />
        <Row k="Toplam Sulama" v={String(totalWaterings)} />
      </div>
    </div>
  );
}

function Vital({ label, value, color = "cyan" }) {
  const c = color === "gold" ? "bg-[#ffb347]" : "bg-cyan-400";
  return (
    <div className="mb-3" data-testid={`vital-${label.toLowerCase().replace(/\s+/g, "-")}`}>
      <div className="flex justify-between text-[11px] font-mono-hud text-cyan-100/70 mb-1">
        <span>{label}</span>
        <span>{value}%</span>
      </div>
      <div className="h-1.5 bg-cyan-900/50 overflow-hidden rounded-sm">
        <div className={`h-full ${c}`} style={{ width: `${value}%`, boxShadow: "0 0 8px currentColor" }} />
      </div>
    </div>
  );
}

function CmdHint({ text }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-cyan-400">›</span>
      <span>&ldquo;{text}&rdquo;</span>
    </div>
  );
}

function Row({ k, v }) {
  return (
    <div className="flex justify-between">
      <span className="opacity-60">{k}</span>
      <span className="text-cyan-200">{v}</span>
    </div>
  );
}
