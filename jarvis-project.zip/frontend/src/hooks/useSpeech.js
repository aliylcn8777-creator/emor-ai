import { useCallback, useEffect, useRef, useState } from "react";

const SpeechRecognitionCtor =
  typeof window !== "undefined" &&
  (window.SpeechRecognition || window.webkitSpeechRecognition);

export default function useSpeech({ onFinalTranscript, onInterimTranscript, onStatusChange }) {
  const [supported, setSupported] = useState(false);
  const recognitionRef = useRef(null);
  const finalTranscriptRef = useRef("");

  useEffect(() => {
    setSupported(!!SpeechRecognitionCtor);
  }, []);

  const speak = useCallback((text) => {
    if (!("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "tr-TR";
      u.rate = 1.02;
      u.pitch = 1.0;
      const voices = window.speechSynthesis.getVoices();
      const tr = voices.find((v) => v.lang && v.lang.toLowerCase().startsWith("tr"));
      if (tr) u.voice = tr;
      u.onstart = () => onStatusChange?.("speaking");
      u.onend = () => onStatusChange?.("idle");
      u.onerror = () => onStatusChange?.("idle");
      window.speechSynthesis.speak(u);
    } catch (err) {
      console.error("TTS error", err);
      onStatusChange?.("idle");
    }
  }, [onStatusChange]);

  const startListening = useCallback((isCurrentlyListening) => {
    if (!SpeechRecognitionCtor) return;
    if (isCurrentlyListening) {
      recognitionRef.current?.stop();
      return;
    }
    try {
      window.speechSynthesis?.cancel();
    } catch (err) {
      console.warn("Failed to cancel TTS before listening", err);
    }
    finalTranscriptRef.current = "";
    const rec = new SpeechRecognitionCtor();
    rec.lang = "tr-TR";
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;
    rec.onstart = () => onStatusChange?.("listening");
    rec.onresult = (ev) => {
      let interim = "";
      let finalT = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const r = ev.results[i];
        if (r.isFinal) finalT += r[0].transcript;
        else interim += r[0].transcript;
      }
      if (finalT) finalTranscriptRef.current = finalT;
      onInterimTranscript?.(finalT || interim);
    };
    rec.onerror = (err) => {
      console.error("Recognition error", err);
      onStatusChange?.("idle");
    };
    rec.onend = () => {
      const final = finalTranscriptRef.current.trim();
      if (final) onFinalTranscript?.(final);
      else onStatusChange?.("idle");
    };
    recognitionRef.current = rec;
    rec.start();
  }, [onFinalTranscript, onInterimTranscript, onStatusChange]);

  return { supported, speak, startListening };
}
