import { useCallback, useEffect, useState } from "react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;
const INITIAL_STATE = { tank_level: 100, moisture: 30, total_waterings: 0 };

export default function useCactus() {
  const [cactus, setCactus] = useState(INITIAL_STATE);

  const fetchState = useCallback(async () => {
    try {
      const { data } = await axios.get(`${API}/cactus/state`);
      setCactus(data);
    } catch (err) {
      console.error("Cactus state error", err);
    }
  }, []);

  const water = useCallback(async () => {
    try {
      const { data } = await axios.post(`${API}/cactus/water`);
      if (data.ok) setCactus(data.state);
      return data;
    } catch (err) {
      console.error("Cactus water error", err);
      return { ok: false };
    }
  }, []);

  const refill = useCallback(async () => {
    try {
      const { data } = await axios.post(`${API}/cactus/refill`);
      setCactus(data.state);
      return data;
    } catch (err) {
      console.error("Cactus refill error", err);
      return { ok: false };
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  return { cactus, setCactus, water, refill };
}
