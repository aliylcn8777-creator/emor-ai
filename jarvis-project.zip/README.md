# 🤖 JARVIS — Sesli AI Asistanı & Kaktüs Sulama Sistemi

Tony Stark'ın J.A.R.V.I.S'inden ilham alan, sesli konuşma destekli, neon-HUD arayüzlü bir yapay zeka asistanı. Türkçe konuşur, OpenAI GPT-4o ile düşünür ve "kaktüse su ver" dediğinizde animasyonlu kaktüsü sular.

## ✨ Özellikler

- 🎙️ **Sesli konuşma** — Web Speech API ile mikrofondan Türkçe komut alır, sesli cevap verir.
- 🧠 **GPT-4o entegrasyonu** — Emergent Universal LLM key üzerinden OpenAI GPT-4o.
- 🌵 **Kaktüs sulama sistemi** — 500ml sanal depo, animasyonlu su seviyesi, nem okuyucu, tek komutla sulama.
- 💎 **Futuristik HUD arayüzü** — Neon cyan, tarama çizgileri, dönen halkalı plazma çekirdek, glassmorphism paneller.
- 💾 **Sohbet geçmişi** — MongoDB'de saklanır.
- 📊 **Canlı sistem paneli** — CPU/Neural Net/Sinyal göstergeleri.

## 🧠 Mimari

```
┌─ Frontend (React 19 + Tailwind)
│   - Web Speech API (SpeechRecognition + SpeechSynthesis)
│   - Jarvis HUD arayüzü
│
└─ Backend (FastAPI)
    - /api/chat            → GPT-4o + intent detection
    - /api/cactus/state    → Tank & nem durumu
    - /api/cactus/water    → Kaktüsü sula
    - /api/cactus/refill   → Depoyu doldur
    - MongoDB (sohbet + kaktüs state)
```

## 🗣️ Örnek Komutlar

| Türkçe Komut | Aksiyon |
|---|---|
| "Kaktüse su ver" | 50ml su verir, tank seviyesini düşürür, nem artar |
| "Depoyu doldur" | Tank %100'e çıkar |
| "Durum nedir?" | Tank ve nem durumunu özetler |
| "Merhaba Jarvis" | Serbest sohbet |

## 🚀 Yerel Kurulum

### Gereksinimler
- Python 3.10+
- Node.js 18+ & Yarn
- MongoDB (lokal veya Atlas)

### Backend
```bash
cd backend
pip install -r requirements.txt
pip install emergentintegrations --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
cp .env.example .env
# .env dosyasını düzenleyin:
#   MONGO_URL="mongodb://localhost:27017"
#   DB_NAME="jarvis"
#   EMERGENT_LLM_KEY="sk-emergent-..."
uvicorn server:app --reload --host 0.0.0.0 --port 8001
```

### Frontend
```bash
cd frontend
yarn install
# .env düzenleyin:
#   REACT_APP_BACKEND_URL=http://localhost:8001
yarn start
```

## 🔑 LLM Key

Emergent Universal Key (`EMERGENT_LLM_KEY`) desteklenen en kolay yöntemdir. Tek anahtarla OpenAI, Anthropic ve Gemini modellerine erişilir. Alternatif olarak kendi OpenAI key'inizi kullanmak isterseniz `backend/server.py` içindeki `LlmChat` çağrısını değiştirin.

## 🌱 Kaktüs Sulama Mantığı

- Tank kapasitesi: 500 ml (%100)
- Her sulama: 50 ml (%10 tank kaybı)
- Sulama sonrası nem +%25 (maks %100)
- Tank boşsa komut reddedilir ve uyarı gelir
- "Depoyu doldur" komutu tankı %100'e çıkarır

## 🎨 Tasarım Felsefesi

- **Palet:** `#030812` (derin uzay siyahı) + `#00e5ff` (neon cyan) + `#ffb347` (alarm altın)
- **Tipografi:** Rajdhani (HUD), JetBrains Mono (okunabilir telemetri)
- **Efektler:** Tarama çizgileri, dönen halkalar, plazma çekirdek, glassmorphism paneller, dalgalı su animasyonu

## 🛠️ Sonraki Adımlar (fikirler)

- Gerçek IoT entegrasyonu (ESP32 + röle üzerinden su pompası)
- ElevenLabs ses sentezi ile daha doğal Jarvis sesi
- Çoklu bitki desteği (orkide, domates, vb.)
- Takvim & hatırlatıcı entegrasyonu

## 📄 Lisans

MIT — özgürce kullanın, geliştirin, paylaşın.

---

*"Sometimes you gotta run before you can walk." — Tony Stark*
